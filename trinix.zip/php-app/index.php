<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trinix Systems</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <img src="assets/images/trinix-systems-logo-small.svg" alt="Trinix Systems Logo" class="logo">
            <h1>Welcome to Trinix Systems</h1>
            <p>Innovative Solutions for Modern Problems</p>
            <a href="#about" class="btn">Learn More</a>
        </div>
    </header>

    <section id="about" class="about-section">
        <div class="container">
            <h2>About Us</h2>
            <p>Trinix Systems is a leading provider of innovative technology solutions. Our team of experts is dedicated to delivering cutting-edge products and services that meet the evolving needs of our clients. With a focus on quality, reliability, and customer satisfaction, we strive to exceed expectations and drive success in every project we undertake.</p>
        </div>
    </section>

    <section id="services" class="services-section">
        <div class="container">
            <h2>Our Services</h2>
            <div class="service-item">
                <h3>Software Development</h3>
                <p>Custom software solutions tailored to your business needs.</p>
            </div>
            <div class="service-item">
                <h3>IT Consulting</h3>
                <p>Expert advice to help you navigate the technology landscape.</p>
            </div>
            <div class="service-item">
                <h3>Cloud Solutions</h3>
                <p>Scalable and secure cloud services to enhance your operations.</p>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Trinix Systems. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

